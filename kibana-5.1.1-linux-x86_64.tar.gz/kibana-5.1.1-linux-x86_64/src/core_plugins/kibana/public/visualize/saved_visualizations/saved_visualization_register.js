export default function savedVisualizationFn(savedVisualizations) {
  return savedVisualizations;
};
