export declare function assignModelProperties(target: any, source: any, defaults: any, removeDefaults?: any): void;
