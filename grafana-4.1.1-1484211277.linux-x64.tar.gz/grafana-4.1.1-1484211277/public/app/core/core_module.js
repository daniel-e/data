/*! grafana - v4.1.1-1484211277 - 2017-01-12
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["angular"],function(a,b){"use strict";var c;b&&b.id;return{setters:[function(a){c=a}],execute:function(){a("default",c.default.module("grafana.core",["ngRoute"]))}}});