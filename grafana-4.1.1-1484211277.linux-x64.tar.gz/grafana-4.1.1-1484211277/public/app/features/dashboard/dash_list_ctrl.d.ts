/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class DashListCtrl {
    /** @ngInject */
    constructor();
}
