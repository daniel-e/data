/*! grafana - v4.1.1-1484211277 - 2017-01-12
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});