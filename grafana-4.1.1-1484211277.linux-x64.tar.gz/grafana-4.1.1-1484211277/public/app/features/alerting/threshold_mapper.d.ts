export declare class ThresholdMapper {
    static alertToGraphThresholds(panel: any): boolean;
}
